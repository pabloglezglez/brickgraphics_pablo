package mosaic.ui.actions;

import mosaic.controllers.StudEditController;
import mosaic.ui.EditTool;
import java.awt.event.ActionEvent;
import javax.swing.AbstractAction;

/**
 * Acción para activar la herramienta cuentagotas.
 */
public class EyedropperToolAction extends AbstractAction {
    private StudEditController studEditController;
    
    public EyedropperToolAction(StudEditController studEditController) {
        super("Eyedropper");
        this.studEditController = studEditController;
        putValue(SHORT_DESCRIPTION, "Eyedropper - Pick color from mosaic");
    }
    
    @Override
    public void actionPerformed(ActionEvent e) {
        studEditController.setActiveTool(EditTool.EYEDROPPER);
    }
}