package mosaic.controllers;

import io.*;

import java.awt.*;
import java.awt.print.*;
import javax.print.PrintService;
import javax.print.PrintServiceLookup;
import java.awt.event.*;
import java.awt.geom.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.util.*;
import java.util.List;
import javax.swing.*;
import javax.swing.event.*;
import javax.swing.SwingUtilities;
import colors.LEGOColor;
import mosaic.controllers.MagnifierController;
import mosaic.io.BrickGraphicsState;
import mosaic.rendering.GrayScaleGraphics2D;
import mosaic.rendering.Pipeline;
import mosaic.rendering.PipelineImageListener;
import mosaic.rendering.PipelineMosaicListener;
import mosaic.ui.*;
import mosaic.ui.dialogs.PrintDialog;
import transforms.ToBricksTransform;
import ui.ProgressDialog;
import icon.*;

/**
 * This class takes care of the printing mechanism
 * @author LD
 */
public class PrintController implements Printable, ModelHandler<BrickGraphicsState>, PipelineImageListener, PipelineMosaicListener {
	private MainController mc;
	private List<ChangeListener> listeners;
	private PageFormat pageFormat;
	private MagnifierController magnifierController;
	private UIController uiController;
	private ColorController colorController;
	private BufferedImage lastPreparedImage;
	private Dimension lastMosaicSize;
	// Model state:
	private boolean coverPageShow, coverPageShowFileName, coverPageShowLegend, showLegend, showPageNumber;
	private float fontSizeMM;
	private int magnifierSizePercentage;
	private String rightCountDisplayText, downCountDisplayText;
	private CoverPagePictureType coverPagePictureType;
	private ShowPosition showPosition;
	private Dimension magnifiersPerPage;
	private PrinterJob printerJob;
	private MainWindow mw;
	
	// Store successful print configuration for reuse
	private boolean hasSuccessfulPrintConfig = false;
	private PrintService lastUsedPrintService;
	private PageFormat savedPageFormat;
	
	/**
	 * Determina si un color es oscuro basándose en su luminosidad.
	 * Usa la fórmula de luminosidad perceptual: 0.299*R + 0.587*G + 0.114*B
	 * @param color El color a evaluar
	 * @return true si el color es oscuro (luminosidad < 128)
	 */
	private static boolean isDarkColor(Color color) {
		// Calcular luminosidad perceptual
		double luminance = 0.299 * color.getRed() + 0.587 * color.getGreen() + 0.114 * color.getBlue();
		return luminance < 128; // Si la luminosidad es menor a 128, consideramos el color como oscuro
	}
	
	/**
	 * Obtiene el color de texto que mejor contrasta con el color de fondo.
	 * @param backgroundColor El color de fondo
	 * @return Color.WHITE para fondos oscuros, Color.BLACK para fondos claros
	 */
	private static Color getContrastingTextColor(Color backgroundColor) {
		return isDarkColor(backgroundColor) ? Color.WHITE : Color.BLACK;
	}
	
	public PrintController(Model<BrickGraphicsState> model, MainController mc, Pipeline pipeline) {
		this.mc = mc;
		magnifierController = mc.getMagnifierController();
		colorController = mc.getColorController();
		uiController = mc.getUIController();
		listeners = new ArrayList<ChangeListener>();		
		printerJob = PrinterJob.getPrinterJob();
		pageFormat = printerJob.defaultPage();
		model.addModelHandler(this);
		handleModelChange(model);
		magnifierController.addChangeListener(new ChangeListener() {
			@Override
			public void stateChanged(ChangeEvent e) {
				notifyListeners(e);
			}
		});

		pipeline.addPreparedImageListener(this);
		pipeline.addMosaicListener(this);
	}
	
	public void setMainWindow(MainWindow mw) {
		this.mw = mw;
	}
	
	public void print() {
		// Ensure print dialog is shown on EDT (Event Dispatch Thread) for JAR compatibility
		if (!SwingUtilities.isEventDispatchThread()) {
			SwingUtilities.invokeLater(() -> print());
			return;
		}
		
		Log.log("About to show print dialog.");
		
		if(mw == null)
			throw new IllegalStateException();
			
		// Create a fresh PrinterJob each time
		printerJob = PrinterJob.getPrinterJob();
		pageFormat = printerJob.defaultPage();
        printerJob.setPrintable(PrintController.this, pageFormat);
        
        boolean dialogResult = false;
        
        // If we have a successful print configuration, offer options to user
        if(hasSuccessfulPrintConfig && lastUsedPrintService != null) {
        	Log.log("Previous print configuration found, asking user for preference.");
        	
        	String[] options = {
        		"Usar Configuración Anterior", 
        		"Configurar Nueva Impresión", 
        		"Mostrar Diálogo Completo",
        		"Cancelar"
        	};
        	
        	int choice = JOptionPane.showOptionDialog(mw,
        		"¿Cómo quieres imprimir?\n\n" +
        		"• Usar Configuración Anterior: " + lastUsedPrintService.getName() + "\n" +
        		"• Configurar Nueva Impresión: Elegir impresora o PDF desde cero\n" +
        		"• Mostrar Diálogo Completo: Ver todas las opciones",
        		"Opciones de Impresión",
        		JOptionPane.YES_NO_CANCEL_OPTION,
        		JOptionPane.QUESTION_MESSAGE,
        		null,
        		options,
        		options[0]);
        		
        	switch(choice) {
        		case 0: // Usar configuración anterior
        			try {
        				printerJob.setPrintService(lastUsedPrintService);
        				pageFormat = savedPageFormat;
        				printerJob.setPrintable(PrintController.this, pageFormat);
        				dialogResult = true;
        				Log.log("Using previous print configuration: " + lastUsedPrintService.getName());
        			} catch(Exception e) {
        				Log.log("Failed to reuse print config: " + e.getMessage());
        				dialogResult = showPrintDialogSafely();
        			}
        			break;
        			
        		case 1: // Configurar Nueva Impresión
        			// Clear saved configuration and restart print system cleanly
        			Log.log("User requested fresh print configuration.");
        			hasSuccessfulPrintConfig = false;
        			lastUsedPrintService = null;
        			savedPageFormat = null;
        			
        			// Create completely fresh PrinterJob
        			try {
        				// Force garbage collection to clear macOS print state
        				System.gc();
        				Thread.sleep(100);
        				
        				// Create brand new PrinterJob
        				printerJob = PrinterJob.getPrinterJob();
        				pageFormat = printerJob.defaultPage();
        				printerJob.setPrintable(PrintController.this, pageFormat);
        				
        				// Show dialog with fresh state
        				dialogResult = showPrintDialogSafely();
        				Log.log("Fresh print dialog shown, result: " + dialogResult);
        				
        				// If first attempt fails (common in macOS), try once more
        				if(!dialogResult) {
        					Log.log("First attempt failed, trying second attempt after brief pause...");
        					Thread.sleep(200);
        					dialogResult = showPrintDialogSafely();
        					Log.log("Second attempt result: " + dialogResult);
        				}
        			} catch(Exception e) {
        				Log.log("Error creating fresh print configuration: " + e.getMessage());
        				JOptionPane.showMessageDialog(mw,
        					"Error al configurar nueva impresión.\n\n" +
        					"Intenta reiniciar la aplicación.",
        					"Error",
        					JOptionPane.WARNING_MESSAGE);
        				return;
        			}
        			break;
        			
        		case 2: // Mostrar diálogo completo
        			dialogResult = showPrintDialogSafely();
        			break;
        			
        		default: // Cancelar
        			Log.log("User cancelled printing.");
        			return;
        	}
        } else {
        	// First time or no saved config, show dialog
        	dialogResult = showPrintDialogSafely();
        }
        
        Log.log("Print dialog result: " + dialogResult);
        
		if(dialogResult) {
			// Save successful print configuration for future use
			if(!hasSuccessfulPrintConfig) {
				try {
					lastUsedPrintService = printerJob.getPrintService();
					savedPageFormat = pageFormat;
					hasSuccessfulPrintConfig = true;
					Log.log("Print configuration saved for future reuse.");
				} catch(Exception e) {
					Log.log("Could not save print configuration: " + e.getMessage());
				}
			}
			
			Log.log("Print dialog confirmed, starting print job directly.");
			
			// Use SwingWorker for background printing without ProgressDialog to avoid blocking
			SwingWorker<Void, Void> printWorker = new SwingWorker<Void, Void>() {
				@Override
				protected Void doInBackground() throws Exception {
			    	try {
			    		Log.log("Initiating printing.");
				    	printerJob.print();
				    	Log.log("Printing completed successfully.");
			    	}
				    catch(PrinterAbortException e1) {
				    	Log.log("Printing aborted.");
				    }
				    catch (PrinterException e2) {
						String message = "An error ocurred while printing: " + e2.getMessage();
						SwingUtilities.invokeLater(() -> {
							JOptionPane.showMessageDialog(mw, message, "Error when printing", JOptionPane.ERROR_MESSAGE);
						});
						Log.log(e2);
				    }
			    	return null;
				}
				
				@Override
				protected void done() {
					Log.log("Print worker finished, cleaning up.");
				}
			};
			Log.log("Executing print worker.");
			printWorker.execute();
		} else {
			// If dialog failed, offer manual export options
			Log.log("Print dialog failed, offering export alternatives.");
			
			// Ensure we're on top and visible
			if(mw != null) {
				mw.setAlwaysOnTop(true);
				mw.toFront();
				mw.requestFocus();
			}
			
			String[] options = {"Reiniciar Impresión", "Instrucciones PDF", "Reintentar", "Cancelar"};
			int choice = JOptionPane.showOptionDialog(mw,
				"El diálogo de impresión no funciona por limitaciones de Java en macOS.\n\n" +
				"Después de la primera impresión, el diálogo del sistema no aparece.\n" +
				"Es una limitación conocida de Java en macOS.\n\n" +
				"Elige una opción para continuar:\n\n" +
				"• Reiniciar Impresión: Resetea solo el sistema de impresión (mantiene configuraciones)\n" +
				"• Instrucciones PDF: Obtén pasos detallados para crear un PDF manualmente\n" +
				"• Reintentar: Intenta el diálogo de impresión una vez más\n" +
				"• Cancelar: Volver a la aplicación",
				"Limitación del Sistema de Impresión - macOS",
				JOptionPane.YES_NO_CANCEL_OPTION,
				JOptionPane.WARNING_MESSAGE,
				null,
				options,
				options[0]);
			
			// Reset always on top
			if(mw != null) {
				mw.setAlwaysOnTop(false);
			}
			
			if(choice == 0) { // Reiniciar Impresión
				Log.log("User chose to restart print system only.");
				restartPrintSystem();
				return;
			} else if(choice == 1) { // Instrucciones PDF
				Log.log("User chose PDF export instructions.");
				exportToPDF();
				return;
			} else if(choice == 2) { // Reintentar
				Log.log("User chose to try print dialog again.");
				// Recursive call to try again
				print();
				return;
			} else {
				Log.log("User cancelled printing.");
				return;
			}
		}
	}
	
	@Override
	public void handleModelChange(Model<BrickGraphicsState> model) {
		coverPageShow = (Boolean)model.get(BrickGraphicsState.PrintCoverPageShow);
		coverPageShowFileName = (Boolean)model.get(BrickGraphicsState.PrintCoverPageShowFileName);
		coverPageShowLegend = (Boolean)model.get(BrickGraphicsState.PrintCoverPageShowLegend);
		coverPagePictureType = CoverPagePictureType.values()[(Integer)model.get(BrickGraphicsState.PrintCoverPageCoverPictureTypeIndex)];
		showPosition = ShowPosition.values()[(Integer)model.get(BrickGraphicsState.PrintShowPositionIndex)];
		showLegend = (Boolean)model.get(BrickGraphicsState.PrintShowLegend);
		showPageNumber = (Boolean)model.get(BrickGraphicsState.PrintShowPageNumber);
		magnifiersPerPage = (Dimension)model.get(BrickGraphicsState.PrintMagnifiersPerPage);
		fontSizeMM = (Float)model.get(BrickGraphicsState.PrintFontSize);
		magnifierSizePercentage = (Integer)model.get(BrickGraphicsState.PrintMagnifierSizePercentage);
		downCountDisplayText = (String)model.get(BrickGraphicsState.PrintDisplayTextDown);
		rightCountDisplayText = (String)model.get(BrickGraphicsState.PrintDisplayTextRight);
	}
	
	public void addChangeListener(ChangeListener l) {
		listeners.add(l);
	}
	
	private void notifyListeners(ChangeEvent e) {
		for(ChangeListener l : listeners) {
			l.stateChanged(e);
		}
	}
	
	public void setDownCountDisplayText(String s, Object caller) {
		downCountDisplayText = s;
		notifyListeners(new ChangeEvent(caller));		
	}
	public void setRightCountDisplayText(String s, Object caller) {
		rightCountDisplayText = s;
		notifyListeners(new ChangeEvent(caller));		
	}
	public void setMagnifierSizePercentage(int i, Object caller) {
		magnifierSizePercentage = i;
		notifyListeners(new ChangeEvent(caller));		
	}
	public void setFontSize(float f, Object caller) {
		fontSizeMM = f;
		notifyListeners(new ChangeEvent(caller));		
	}
	public void setCoverPageShow(boolean b, Object caller) {
		coverPageShow = b;
		notifyListeners(new ChangeEvent(caller));
	}
	public void setCoverPageShowFileName(boolean b, Object caller) {
		coverPageShowFileName = b;
		notifyListeners(new ChangeEvent(caller));
	}
	public void setCoverPageShowLegend(boolean b, Object caller) {
		coverPageShowLegend = b;
		notifyListeners(new ChangeEvent(caller));
	}
	public void setShowColors(boolean b, Object caller) {
		uiController.setShowColors(b);
		notifyListeners(new ChangeEvent(caller));
	}
	public void setShowLegend(boolean b, Object caller) {
		showLegend = b;
		notifyListeners(new ChangeEvent(caller));
	}
	public void setShowPageNumber(boolean b, Object caller) {
		showPageNumber = b;
		notifyListeners(new ChangeEvent(caller));
	}
	public void setCoverPagePictureType(CoverPagePictureType c, Object caller) {
		coverPagePictureType = c;
		notifyListeners(new ChangeEvent(caller));
	}
	public void setPageFormat(PageFormat p, Object caller) {
		pageFormat = p;
		notifyListeners(new ChangeEvent(caller));
	}
	public void setShowPosition(ShowPosition s, Object caller) {
		showPosition = s;
		notifyListeners(new ChangeEvent(caller));
	}
	public void setMagnifiersPerPage(Dimension d, Object caller) {
		magnifiersPerPage = d;
		notifyListeners(new ChangeEvent(caller));		
	}	
	public float getFontSize() {
		return fontSizeMM;
	}
	public int getMagnifierSizePercentage() {
		return magnifierSizePercentage;
	}
	public boolean getCoverPageShow() {
		return coverPageShow;
	}
	public boolean getCoverPageShowFileName() {
		return coverPageShowFileName;
	}
	public boolean getCoverPageShowLegend() {
		return coverPageShowLegend;
	}
	public boolean getShowColors() {
		return uiController.showColors();
	}
	public boolean getShowLegend() {
		return showLegend;
	}
	public boolean getShowPageNumber() {
		return showPageNumber;
	}
	public String getDownCountDisplayText() {
		return downCountDisplayText;
	}
	public String getRightCountDisplayText() {
		return rightCountDisplayText;
	}
	public CoverPagePictureType getCoverPagePictureType() {
		return coverPagePictureType;
	}
	public PageFormat getPageFormat() {
		return pageFormat;
	}
	public ShowPosition getShowPosition() {
		return showPosition;
	}
	public Dimension getMagnifiersPerPage() {
		return magnifiersPerPage;		
	}
	public PrinterJob getPrinterJob() {
		return printerJob;
	}
	
	public static Action createPrintAction(final PrintDialog printDialog) {
		Action printAction = new AbstractAction() {
			@Override
			public void actionPerformed(ActionEvent e) {
				printDialog.pack();
				printDialog.setVisible(true);
			}
		};

		printAction.putValue(Action.SHORT_DESCRIPTION, "Print the mosaic.");
		printAction.putValue(Action.SMALL_ICON, Icons.get(16, "printer", "PRINT"));
		printAction.putValue(Action.LARGE_ICON_KEY, Icons.get(32, "printer", "PRINT"));
		printAction.putValue(Action.NAME, "Print");
		printAction.putValue(Action.MNEMONIC_KEY, KeyEvent.VK_P);
		printAction.putValue(Action.DISPLAYED_MNEMONIC_INDEX_KEY, "Print".indexOf('P'));
		printAction.putValue(Action.ACCELERATOR_KEY, KeyStroke.getKeyStroke(KeyEvent.VK_P, InputEvent.CTRL_DOWN_MASK));

		return printAction;
	}

	private double writeFileName(FontMetrics fm, int xMin, int xMax, int yMin, Graphics2D g2, int fontSizeIn1_72inches) {
		if(!coverPageShowFileName) 
			return 0;

		File f = mc.getFile();
		String s = f == null ? "-" : f.getName();
		Rectangle2D bounds = fm.getStringBounds(s, g2);
		float x = xMin + (float)((xMax-xMin)-bounds.getWidth())/2;
		float y = yMin + fontSizeIn1_72inches*8/10;
		g2.drawString(s, x, y);
		return fontSizeIn1_72inches*1.2; // 2.2 to make a little bit of space above the letters
	}
	
	private int drawbom(Graphics2D g2, int xMin, int xMax, int yMin, int yMax, int fontSizeIn1_72inches) {
		if(mw == null || !coverPageShowLegend)
			return 0;
		
		if(coverPagePictureType != CoverPagePictureType.None) {
			yMax = yMin + (yMax-yMin)/2;
		}
		LEGOColor.CountingLEGOColor[] bom = mw.getBrickedView().getLegendColors();
		
		int rowHeight = fontSizeIn1_72inches*6/5;
		int rows = Math.max(1, (yMax-yMin)/rowHeight);		
		int columns = Math.max(1, (bom.length+rows-1)/rows);
		int columnWidth = (xMax-xMin)/columns;
		int i = 0;
		int textHeight = fontSizeIn1_72inches;

		for(LEGOColor.CountingLEGOColor c : bom) {
			int x = i%columns;
			int y = i/columns;

			g2.setColor(Color.WHITE);
			int xIndent = xMin + x*columnWidth;
			int yIndent = yMin + y*rowHeight;
			g2.fillRect(xIndent, yIndent, columnWidth, rowHeight);
			
			// Dibujar círculo inscrito en lugar de cuadrado
			g2.setColor(c.c.getRGB());
			int diameter = fontSizeIn1_72inches;
			int circleX = xIndent;
			int circleY = yIndent;
			g2.fillOval(circleX, circleY, diameter, diameter);
			
			// Añadir contorno negro para círculos de cover page
			g2.setColor(Color.BLACK);
			Stroke originalStroke = g2.getStroke();
			g2.setStroke(new BasicStroke(1.0f));
			g2.drawOval(circleX, circleY, diameter, diameter);
			g2.setStroke(originalStroke);
			
			// Añadir número identificador centrado dentro del círculo (igual que en drawLegend)
			Font originalFont = g2.getFont();
			Font numberFont = new Font("Monospaced", Font.BOLD, diameter * 2 / 3);
			g2.setFont(numberFont);
			
			// Priorizar números personalizados si existen
			String numberSymbol = "?";
			Integer customNumber = colorController.getCustomColorID(c.c);
			if (customNumber != null) {
				numberSymbol = customNumber.toString();
			} else {
				String colorId = colorController.getNormalIdentifier(c.c);
				if (colorId != null) {
					// Extraer solo la parte antes de la coma (el número)
					int commaIndex = colorId.indexOf(",");
					if (commaIndex != -1) {
						numberSymbol = colorId.substring(0, commaIndex).trim();
					} else {
						numberSymbol = colorId.trim();
					}
				}
			}
			
			// Calcular posición centrada para el número dentro del círculo
			FontMetrics fm = g2.getFontMetrics();
			int textWidth = fm.stringWidth(numberSymbol);
			int numberHeight = fm.getAscent();
			int textX = circleX + (diameter - textWidth) / 2;
			int textY = circleY + diameter / 2 + numberHeight / 2 - fm.getDescent() / 2;
			
			// Usar color inteligente que contraste con el fondo del círculo
			Color bgColor = c.c.getRGB();
			double brightness = (0.299 * bgColor.getRed() + 0.587 * bgColor.getGreen() + 0.114 * bgColor.getBlue()) / 255.0;
			Color textColor = brightness > 0.5 ? Color.BLACK : Color.WHITE;
			g2.setColor(textColor);
			g2.drawString(numberSymbol, textX, textY);
			
			// Restaurar font y color negro para el texto de cantidad
			g2.setFont(originalFont);
			g2.setColor(Color.BLACK);
			
			// Construir el texto para mostrar junto al círculo: Nombre del color x Cantidad
			String displayText = "";
			if (customNumber != null) {
				// Para números personalizados, mostrar: nombre del color x cantidad
				String colorName = colorController.getShownName(c.c);
				if (colorName != null && !colorName.trim().isEmpty()) {
					displayText = colorName + " x " + c.cnt;
				} else {
					displayText = "x " + c.cnt;
				}
			} else {
				// Para números automáticos, usar el identificador normal sin el número
				String identifier = colorController.getNormalIdentifier(c.c);
				if (identifier != null) {
					// Extraer solo el nombre del color, omitiendo el número al inicio
					String colorName = identifier;
					int commaIndex = identifier.indexOf(",");
					if (commaIndex != -1) {
						colorName = identifier.substring(commaIndex + 1).trim();
					}
					displayText = colorName + " x " + c.cnt;
				} else {
					displayText = "x " + c.cnt;
				}
			}
			
			g2.drawString(displayText, 
					xMin + x*columnWidth + rowHeight, 
					yMin + y*rowHeight + fontSizeIn1_72inches*9/10 - (fontSizeIn1_72inches - textHeight)/2);

			++i;
		}
		return yMax;
	}
		
	private static Rectangle getSizeOfDrawnImage(int xMin, int xMax, int yMin, int yMax, Dimension imageSize) {
		double scale = (xMax-xMin)/imageSize.getWidth();
		if(scale*imageSize.getHeight() > (yMax-yMin)) {
			scale = (yMax-yMin)/imageSize.getHeight();			
		}
		int x = (int)(xMin + ((xMax-xMin)-imageSize.width*scale));
		return new Rectangle(x, yMin, (int)(scale*imageSize.width), (int)(scale*imageSize.height));
	}

	private static void drawImage(Graphics2D g2, int xMin, int xMax, int yMin, int yMax, BufferedImage image) {
		double scale = (xMax-xMin)/(double)image.getWidth();
		if(scale*image.getHeight() > (yMax-yMin)) {
			scale = (yMax-yMin)/(double)image.getHeight();			
		}
		AffineTransform at = AffineTransform.getScaleInstance(scale, scale);
		int x = (int)(xMin + ((xMax-xMin)-image.getWidth()*scale));
		g2.translate(x, yMin);
		g2.drawImage(image, at, null);
		g2.translate(-x, -yMin);		
	}
	
	private void drawCoverPicture(Graphics2D g2, PageFormat pf, FontMetrics fm, int xMin, int xMax, int yMin, int yMax) {
		if(coverPagePictureType == CoverPagePictureType.Both) {
			BufferedImage left = lastPreparedImage;
			drawImage(g2, xMin, xMin + (xMax-xMin)*9/20, yMin, yMax, left);
			
			int startX = xMin + (xMax-xMin)*11/20;
			Rectangle drawRect = getSizeOfDrawnImage(startX, xMax, yMin, yMax, lastMosaicSize);
			g2.translate(drawRect.x, drawRect.y);
			mw.getBrickedView().getToBricksTransform().drawAll(g2, new Dimension(drawRect.width, drawRect.height));
			g2.translate(-drawRect.x, -drawRect.y);
		}
		else if(coverPagePictureType == CoverPagePictureType.Original) {
			drawImage(g2, xMin, xMax, yMin, yMax, lastPreparedImage);
		}
		else if(coverPagePictureType == CoverPagePictureType.Mosaic) {
			Rectangle drawRect = getSizeOfDrawnImage(xMin, xMax, yMin, yMax, lastMosaicSize);
			g2.translate(xMin, yMin);
			mw.getBrickedView().getToBricksTransform().drawAll(g2, new Dimension(drawRect.width, drawRect.height));
			g2.translate(-xMin, -yMin);
		}
		else if(coverPagePictureType == CoverPagePictureType.Overview) {
			//g2.translate(xMin, yMin);
			//g2.translate(-xMin, -yMin);
			
			Dimension coreImage = magnifierController.getCoreImageSizeInCoreUnits();
			Dimension magnifierSizeInCoreUnits = magnifierController.getSizeInUnits();

			Dimension oldMagnifiersPerPage = magnifiersPerPage;
			magnifiersPerPage = new Dimension(coreImage.width / magnifierSizeInCoreUnits.width, 
											  coreImage.height / magnifierSizeInCoreUnits.height);
			int pageSizeInCoreUnitsW = magnifierSizeInCoreUnits.width * magnifiersPerPage.width;
			int pageSizeInCoreUnitsH = magnifierSizeInCoreUnits.height * magnifiersPerPage.height;
			
			drawMagnifier(g2, 0, 1, 1, xMin, xMax, yMin, yMax, pageSizeInCoreUnitsW, pageSizeInCoreUnitsH, pf, fm, null);		
			magnifiersPerPage = oldMagnifiersPerPage;
		}
	}
	
	private void printCoverPage(Graphics2D g2, PageFormat pf) {
	    // Find bounds:
		final int xMin = (int)pf.getImageableX();
		final int xMax = (int)(pf.getImageableWidth() + pf.getImageableX());
		int yMin = (int)pf.getImageableY();
		int yMax = (int)(pf.getImageableHeight() + pf.getImageableY());
		final int fontSizeIn1_72inches = getFontSizeIn1_72inches(pf);
		
		// Compute font:
		Font font = new Font("SansSerif", Font.PLAIN, fontSizeIn1_72inches);
		g2.setFont(font);
		g2.setColor(Color.BLACK);
		FontMetrics fm = g2.getFontMetrics(font);

		// File name:
		yMin += writeFileName(fm, xMin, xMax, yMin, g2, fontSizeIn1_72inches);
		
		// BOM:
		yMin = drawbom(g2, xMin, xMax, yMin, yMax, fontSizeIn1_72inches);
		
		// Cover picture:
		drawCoverPicture(g2, pf, fm, xMin, xMax, yMin, yMax);
	}
	
	private int getFontSizeIn1_72inches(PageFormat pf) {
	    double heightInInches = pf.getImageableHeight()/72;
	    double heightInMM = heightInInches * 25.4;
		return (int)(pf.getImageableHeight() * fontSizeMM / heightInMM);		
	}
	
	/*
	 * Return how much to decrease xMax.
	 */
	private double writePageNumber(int page, int numberOfPages, FontMetrics fm, int xMin, int xMax, int yMax, Graphics2D g2, int fontSizeIn1_72inches) {
		if(!showPageNumber) 
			return 0;
						
		String pageNumberString = (page+1) + " / " + numberOfPages;
		Rectangle2D pageNumberStringBounds = fm.getStringBounds(pageNumberString, g2);
		float x = xMin + (float)((xMax-xMin)-pageNumberStringBounds.getWidth())/2;
		float y = yMax - fontSizeIn1_72inches/20;
		g2.drawString(pageNumberString, x, y);
		return fontSizeIn1_72inches*1.1; // 2.2 to make a little bit of space above the letters
	}
	
	private static void drawHorizontalArrow(Graphics2D g2, int leftX, int y, int rightX, int arrowSize) {
		g2.drawLine(leftX, y, rightX, y);
		g2.drawLine(leftX,  y, leftX+arrowSize, y+arrowSize);
		g2.drawLine(leftX,  y, leftX+arrowSize, y-arrowSize);
		g2.drawLine(rightX,  y, rightX-arrowSize, y+arrowSize);
		g2.drawLine(rightX,  y, rightX-arrowSize, y-arrowSize);
	}
	
	private static void drawVerticalArrow(Graphics2D g2, int x, int topY, int bottomY, int arrowSize) {
		g2.drawLine(x, topY, x, bottomY);
		g2.drawLine(x, topY, x+arrowSize, topY+arrowSize);
		g2.drawLine(x, topY, x-arrowSize, topY+arrowSize);
		g2.drawLine(x, bottomY, x+arrowSize, bottomY-arrowSize);
		g2.drawLine(x, bottomY, x-arrowSize, bottomY-arrowSize);
	}
	
	public double drawShownPositionForMagnifier(Graphics2D g2, int page, int xMax, int yMax) {
		int unit = 20;
		int yMin = 6;

		if(showPosition == ShowPosition.Written) {
			g2.setFont(new Font("Arial", Font.BOLD, 40));
			unit = 45;
			yMin = 10;
		}
		FontMetrics fm = g2.getFontMetrics();

		Dimension coreImageSizeInCoreUnits = magnifierController.getCoreImageSizeInCoreUnits();
		if(coreImageSizeInCoreUnits == null)
			return 0; // Not ready.
		final int coreImageInCoreUnitsW = coreImageSizeInCoreUnits.width;
		final int coreImageInCoreUnitsH = coreImageSizeInCoreUnits.height;
		final Dimension magnifierSizeInCoreUnits = magnifierController.getSizeInUnits();
		final int pageSizeInCoreUnitsW = magnifierSizeInCoreUnits.width;
		final int pageSizeInCoreUnitsH = magnifierSizeInCoreUnits.height;

		final int numPagesWidth = (coreImageInCoreUnitsW+pageSizeInCoreUnitsW-1) / pageSizeInCoreUnitsW;
		final int numPagesHeight = (coreImageInCoreUnitsH+pageSizeInCoreUnitsH-1) / pageSizeInCoreUnitsH;		
		
		return drawShowPosition(page, numPagesWidth, numPagesHeight, fm, 
				0, xMax, yMin, yMax, g2, unit, coreImageSizeInCoreUnits, magnifierSizeInCoreUnits);
	}
	
	private double drawShowPosition(int page, int numPagesWidth, int numPagesHeight, FontMetrics fm, 
			int xMin, int xMax, int yMin, int yMax, 
			Graphics2D g2, int unit, Dimension coreImageInCoreUnits, Dimension pageSizeInCoreUnits) {
		// Nothing:
		if(showPosition == ShowPosition.None)
			return 0;

		int fromLeft = (page % numPagesWidth)+1;
		int fromTop = (page / numPagesWidth)+1;

		// Written:
		if(showPosition == ShowPosition.Written || showPosition == ShowPosition.TextAndBox) {
			String pageNumberString = fromLeft + rightCountDisplayText + fromTop + downCountDisplayText;
			Rectangle2D pageNumberStringBounds = fm.getStringBounds(pageNumberString, g2);
			float x = xMin + (float)((xMax-xMin)-pageNumberStringBounds.getWidth())/2;
			float y = yMin + unit;
			g2.drawString(pageNumberString, x, y);
			if(showPosition == ShowPosition.Written)
				return unit*1.2; // 1.2 to make a little bit of space above the letters
			yMin += unit*2;
		}
		
		// Boxes:
		int xMid = (xMax+xMin)/2;
		int arrowSize = unit/5;			

		String leftText = ""+(fromLeft-1);
		Rectangle2D leftTextStringBounds = fm.getStringBounds(leftText, g2);
		String rightText = ""+(numPagesWidth-fromLeft);
		Rectangle2D rightTextStringBounds = fm.getStringBounds(rightText, g2);
		String topText = ""+(fromTop-1);
		String bottomText = ""+(numPagesHeight-fromTop);
		
		if(showPosition == ShowPosition.MiddleBox) { // Show box in middle: 3x1, 2 on top/bottom, 3 on left/right. Unit is fontSizeIn1_72inches
			int outerWidth = 9*unit;
			int outerHeight = 5*unit;
			int leftX = xMid-outerWidth/2;
			int rightX = leftX+outerWidth;
			g2.drawRect(leftX, yMin, outerWidth, outerHeight); // Outer box
			g2.drawRect(xMid-unit, yMin+2*unit, 2*unit, unit); // Inner box
			int horizontalArrowY = yMin+5*unit/2-arrowSize;
			drawHorizontalArrow(g2, leftX, horizontalArrowY, xMid-unit, arrowSize); // left arrow
			drawHorizontalArrow(g2, xMid+unit, horizontalArrowY, rightX, arrowSize); // right arrow
			drawVerticalArrow(g2, xMid, yMin, yMin+2*unit, arrowSize);
			drawVerticalArrow(g2, xMid, yMin+3*unit, yMin+outerHeight, arrowSize);
			g2.drawString(topText, xMid + arrowSize, yMin + 3*unit/2);
			g2.drawString(bottomText, xMid + arrowSize, yMin + 9*unit/2);
			g2.drawString(leftText, xMid - 4*unit + (int)(3*unit-leftTextStringBounds.getWidth())/2, horizontalArrowY + arrowSize + unit);
			g2.drawString(rightText, xMid + unit + (int)(3*unit-rightTextStringBounds.getWidth())/2, horizontalArrowY + arrowSize + unit);
			return outerHeight + unit/5;
		}
		else { // "Smart" box
			int outerHeight = Math.max(5*unit, (yMax-yMin)/5);
			int outerBoxHeight = outerHeight - unit - 2*arrowSize;
			int outerBoxWidth = (outerBoxHeight * coreImageInCoreUnits.width) / coreImageInCoreUnits.height;
			if(outerBoxWidth > 0.8 * (xMax-xMin)) {
				outerBoxWidth = (int)(0.8 * (xMax-xMin));
				outerBoxHeight = (outerBoxWidth * coreImageInCoreUnits.height) / coreImageInCoreUnits.width;
				outerHeight = outerBoxHeight + unit + 2*arrowSize;
			}
			double innerBoxHeight = outerBoxHeight/(double)numPagesHeight;
			double innerBoxWidth = outerBoxWidth/(double)numPagesWidth;
			// boxes and lines:
			int outerBoxX = xMid - outerBoxWidth/2;
			
			// Draw gray picture:
			int grayWidth = (int)Math.round(outerBoxWidth * coreImageInCoreUnits.width/((double)pageSizeInCoreUnits.width*numPagesWidth));
			int grayHeight = (int)Math.round(outerBoxHeight * coreImageInCoreUnits.height/((double)pageSizeInCoreUnits.height*numPagesHeight));
			g2.translate(outerBoxX, yMin);
			mw.getBrickedView().getToBricksTransform().drawAll(new GrayScaleGraphics2D(g2), new Dimension(grayWidth, grayHeight));
			g2.translate(-outerBoxX, -yMin);
			
			g2.drawRect(outerBoxX, yMin, outerBoxWidth, outerBoxHeight);
			int xLeft = outerBoxX + (int)((fromLeft-1)*innerBoxWidth);
			int xRight = outerBoxX + (int)(fromLeft*innerBoxWidth);
			int yTop = yMin + (int)((fromTop-1)*innerBoxHeight);
			int yBottom = yMin + (int)(fromTop*innerBoxHeight);
			g2.setColor(Color.RED);
			g2.fillRect(xLeft, yTop, (int)innerBoxWidth+1, (int)innerBoxHeight+1);
			g2.setColor(Color.BLACK);
			
			if(showPosition == ShowPosition.TextAndBox) {
				g2.drawRect(xLeft, yTop, (int)innerBoxWidth+1, (int)innerBoxHeight+1);
				return outerHeight + 2.2*unit;
			}
			g2.drawLine(outerBoxX, yTop, outerBoxX+outerBoxWidth, yTop);
			g2.drawLine(outerBoxX, yBottom, outerBoxX+outerBoxWidth, yBottom);
			g2.drawLine(xLeft, yMin, xLeft, yMin+outerBoxHeight);
			g2.drawLine(xRight, yMin, xRight, yMin+outerBoxHeight);
			// Arrows & text:
			if(fromLeft > 1) {
				drawHorizontalArrow(g2, outerBoxX, yMin+outerBoxHeight+arrowSize, xLeft, arrowSize);
				g2.drawString(leftText, outerBoxX + (int)(xLeft-outerBoxX-leftTextStringBounds.getWidth())/2, yMin+outerHeight-unit/10);				
			}
			if(numPagesWidth-fromLeft> 0) {
				drawHorizontalArrow(g2, xRight, yMin+outerBoxHeight+arrowSize, outerBoxX + outerBoxWidth, arrowSize);
				g2.drawString(rightText, xRight + (int)(outerBoxX+outerBoxWidth-xRight-rightTextStringBounds.getWidth())/2, yMin+outerHeight-unit/10);				
			}
			int rightArrowX = outerBoxX + outerBoxWidth + arrowSize;
			if(fromTop > 1) {
				drawVerticalArrow(g2, rightArrowX, yMin, yTop, arrowSize);
				g2.drawString(topText, rightArrowX + arrowSize, yMin + (yTop-yMin+unit)/2);				
			}
			if(numPagesHeight-fromTop > 0) {
				drawVerticalArrow(g2, rightArrowX, yBottom, yMin + outerBoxHeight, arrowSize);
				g2.drawString(bottomText, rightArrowX + arrowSize, yBottom + (yMin+outerBoxHeight-yBottom+unit)/2);				
			}
			
			return outerHeight + unit/5;
		}
	}
	
	private int drawMagnifier(Graphics2D g2, int page, int numPagesWidth, int numPagesHeight, int xMin, int xMax, int yMin, int yMax, int pageSizeInCoreUnitsW, int pageSizeInCoreUnitsH, PageFormat pf, FontMetrics fm, Set<LEGOColor.CountingLEGOColor> used) {
		// Find out how big each page is (compared to full image):
		Dimension shownMagnifierSize = new Dimension((int)pf.getImageableWidth(), (int)((pf.getImageableWidth() * pageSizeInCoreUnitsH) / pageSizeInCoreUnitsW));
		int indentX = xMin;
		int indentY = yMax - shownMagnifierSize.height;
		if(shownMagnifierSize.height > (yMax-yMin)*magnifierSizePercentage/100) {
			shownMagnifierSize.height = (yMax-yMin)*magnifierSizePercentage/100;
			shownMagnifierSize.width = (shownMagnifierSize.height * pageSizeInCoreUnitsW) / pageSizeInCoreUnitsH;
			indentX = (xMax+xMin-shownMagnifierSize.width)/2;
			indentY = yMax - shownMagnifierSize.height;
		}
		Dimension smallMagnifierSize;
		if(shownMagnifierSize.width == 1 && shownMagnifierSize.height == 1) {
			smallMagnifierSize = shownMagnifierSize;
		}
		else {
			smallMagnifierSize = new Dimension((int)(shownMagnifierSize.width / magnifiersPerPage.width*0.95), 
											   (int)(shownMagnifierSize.height / magnifiersPerPage.height*0.95));
		}

		// draw magnified:
		g2.translate(indentX, indentY);
		ToBricksTransform tbTransform = magnifierController.getTBTransform();

		Rectangle basicUnitRect = magnifierController.getCoreRect();
		//int smallPage = 1;
		for(int y = 0; y < magnifiersPerPage.height; ++y) {
			int yIndent = y*shownMagnifierSize.height/magnifiersPerPage.height;
			g2.translate(0, yIndent);

			for(int x = 0; x < magnifiersPerPage.width; ++x) {
				int xIndent = x*shownMagnifierSize.width/magnifiersPerPage.width;
				
				basicUnitRect.x = ((page % numPagesWidth)*magnifiersPerPage.width + x)*basicUnitRect.width;
				basicUnitRect.y = (/*numPagesHeight-1-*/ (page / numPagesWidth) * magnifiersPerPage.height + y)*basicUnitRect.height; // Add numPagesHeight-1- in first parenthesis to start from bottom.

				g2.translate(xIndent, 0);
				LEGOColor.CountingLEGOColor[] m = tbTransform.draw(g2, basicUnitRect, smallMagnifierSize, uiController.showColors(), used != null, true); // true = for print instructions
				
				
				
				/*
				
				String ss = "" + smallPage++;
				Rectangle2D stringBounds = fm.getStringBounds(ss, g2);
				Rectangle2D stringBounds3 = fm.getStringBounds("abc", g2);
				int boxWidth = (int)(1.3*stringBounds3.getWidth());
				int boxHeight = (int)(1.1*stringBounds.getHeight());
				//g2.drawString(leftText, xMid - 4*unit + (int)(3*unit-leftTextStringBounds.getWidth())/2, horizontalArrowY + arrowSize + unit);
				int ww = smallMagnifierSize.width/2;
				int hh = smallMagnifierSize.height/2;
				int xx = ww - boxWidth/2;
				int yy = hh - boxHeight/2;
				g2.setColor(Color.WHITE);
				g2.fillRect(xx, yy, boxWidth, boxHeight);
				g2.setColor(Color.BLACK);
				g2.drawRect(xx, yy, boxWidth, boxHeight);
				g2.drawString(""+ss, (int)(ww-stringBounds.getWidth()/2), (int)(hh+stringBounds.getHeight()*0.38));//*/
				
				
				
				
				
				
				
				g2.translate(-xIndent, 0);
				if(used != null) {
					for(int i = 0; i < m.length; ++i)
						used.add(m[i]);					
				}
			}
			g2.translate(0, -yIndent);
		}
		
		g2.translate(-indentX, -indentY);		
		return indentY;
	}
	
	private void drawLegend(Graphics2D g2, int xMin, int xMax, int yMin, int yMax, int fontSizeIn1_72inches, Set<LEGOColor.CountingLEGOColor> used) {
		if(!showLegend)
			return;
		int rowHeight = fontSizeIn1_72inches*6/5;
		int rows = Math.max(1, (yMax-yMin)/rowHeight);
		int columns = Math.max(1, (used.size()+rows-1)/rows);
		int columnWidth = Math.max(1, (xMax-xMin)/columns);
		int i = 0;
		
		int textHeight = fontSizeIn1_72inches;

		for(LEGOColor.CountingLEGOColor cc : used) {
			LEGOColor c = cc.c;
			int x = i%columns;
			int y = i/columns;

			g2.setColor(Color.WHITE);
			int xIndent = xMin + x*columnWidth;
			int yIndent = yMin + y*rowHeight;
			g2.fillRect(xIndent, yIndent, columnWidth, rowHeight);
			
			// Dibujar círculo inscrito en lugar de cuadrado
			g2.setColor(c.getRGB());
			int diameter = fontSizeIn1_72inches;
			int circleX = xIndent;
			int circleY = yIndent;
			g2.fillOval(circleX, circleY, diameter, diameter);
			
			// Añadir contorno negro para círculos de leyenda
			g2.setColor(Color.BLACK);
			Stroke originalStroke = g2.getStroke();
			g2.setStroke(new BasicStroke(1.0f));
			g2.drawOval(circleX, circleY, diameter, diameter);
			g2.setStroke(originalStroke);
			
			// Añadir número identificador centrado dentro del círculo con color inteligente
			Font originalFont = g2.getFont();
			Font numberFont = new Font("Monospaced", Font.BOLD, diameter * 2 / 3);
			g2.setFont(numberFont);
			
			// Obtener el número identificador del color
			// Priorizar números personalizados si existen
			String numberSymbol = "?";
			Integer customNumber = colorController.getCustomColorID(c);
			if (customNumber != null) {
				numberSymbol = customNumber.toString();
			} else {
				String colorId = colorController.getNormalIdentifier(c);
				if (colorId != null) {
					// Extraer solo la parte antes de la coma (el número)
					int commaIndex = colorId.indexOf(",");
					if (commaIndex != -1) {
						numberSymbol = colorId.substring(0, commaIndex).trim();
					} else {
						numberSymbol = colorId.trim();
					}
				}
			}
			
			// Calcular posición centrada para el número
			FontMetrics fm = g2.getFontMetrics();
			int textWidth = fm.stringWidth(numberSymbol);
			int numberHeight = fm.getAscent();
			int textX = circleX + (diameter - textWidth) / 2;
			int textY = circleY + diameter / 2 + numberHeight / 2 - fm.getDescent() / 2;
			
			// Usar color inteligente que contraste con el fondo del círculo
			Color bgColor = c.getRGB();
			int brightness = (bgColor.getRed() + bgColor.getGreen() + bgColor.getBlue()) / 3;
			Color textColor = brightness < 128 ? Color.WHITE : Color.BLACK;
			
			g2.setColor(textColor);
			g2.drawString(numberSymbol, textX, textY);
			
			// Restaurar fuente original
			g2.setFont(originalFont);
			
			// Restaurar color negro para el texto
			g2.setColor(Color.BLACK);
			// Mostrar nombre del color y cantidad con símbolo X
			String colorName = colorController.getShownName(c);
			String textWithCount = (colorName != null ? colorName + " " : "") + "(X" + cc.cnt + ")";
			g2.drawString(textWithCount, 
				xMin + x*columnWidth + rowHeight, 
				yMin + y*rowHeight + fontSizeIn1_72inches*9/10 - (fontSizeIn1_72inches - textHeight)/2);
			++i;
		}
	}
	
	public int getNumberOfPages() {
		// Find out how big the magnifier is:
		Dimension coreImage = magnifierController.getCoreImageSizeInCoreUnits();
		if(coreImage == null)
			return 0; // Not ready.
		final int coreImageInCoreUnitsW = coreImage.width;
		final int coreImageInCoreUnitsH = coreImage.height;
		final Dimension magnifierSizeInCoreUnits = magnifierController.getSizeInUnits();
		final int pageSizeInCoreUnitsW = magnifierSizeInCoreUnits.width * magnifiersPerPage.width;
		final int pageSizeInCoreUnitsH = magnifierSizeInCoreUnits.height * magnifiersPerPage.height;

		final int numPagesWidth = (coreImageInCoreUnitsW+pageSizeInCoreUnitsW-1) / pageSizeInCoreUnitsW;
		final int numPagesHeight = (coreImageInCoreUnitsH+pageSizeInCoreUnitsH-1) / pageSizeInCoreUnitsH;		
		return numPagesWidth*numPagesHeight; 		
	}
	
	@Override
	public int print(Graphics g, PageFormat pf, int page) throws PrinterException {
		Graphics2D g2 = (Graphics2D)g;
		
		// Find out how big the magnifier is:
		final int coreImageInCoreUnitsW = magnifierController.getCoreImageSizeInCoreUnits().width;
		final int coreImageInCoreUnitsH = magnifierController.getCoreImageSizeInCoreUnits().height;
		final Dimension coreImageInCoreUnits = new Dimension(coreImageInCoreUnitsW, coreImageInCoreUnitsH);
		final Dimension magnifierSizeInCoreUnits = magnifierController.getSizeInUnits();
		final int pageSizeInCoreUnitsW = magnifierSizeInCoreUnits.width * magnifiersPerPage.width;
		final int pageSizeInCoreUnitsH = magnifierSizeInCoreUnits.height * magnifiersPerPage.height;
		final Dimension pageSizeInCoreUnits = new Dimension(pageSizeInCoreUnitsW, pageSizeInCoreUnitsH);

		final int numPagesWidth = (coreImageInCoreUnitsW+pageSizeInCoreUnitsW-1) / pageSizeInCoreUnitsW;
		final int numPagesHeight = (coreImageInCoreUnitsH+pageSizeInCoreUnitsH-1) / pageSizeInCoreUnitsH;		
		final int numberOfPages = numPagesWidth*numPagesHeight; 
		
		// Log progress for debugging
		Log.log("Rendering page " + page + " of " + (numberOfPages + (coverPageShow ? 1 : 0)) + ".");
		
		// Special case: Cover page:
		if(page == 0 && coverPageShow) {
			printCoverPage(g2, pf);
			return PAGE_EXISTS;
		}
		if(coverPageShow)
			--page;
		
	    if (page >= numberOfPages) {
	    	return NO_SUCH_PAGE;
	    }
	    
	    // Find bounds:
		final int xMin = (int)pf.getImageableX();
		final int xMax = (int)(pf.getImageableWidth() + pf.getImageableX());
		int yMin = (int)pf.getImageableY();
		int yMax = (int)(pf.getImageableHeight() + pf.getImageableY());
		final int fontSizeIn1_72inches = getFontSizeIn1_72inches(pf);
		
		// Compute font:
		Font font = new Font("SansSerif", Font.PLAIN, fontSizeIn1_72inches);
		g2.setFont(font);
		g2.setColor(Color.BLACK);
		FontMetrics fm = g2.getFontMetrics(font);

		// Page number:
		yMax -= writePageNumber(page, numberOfPages, fm, xMin, xMax, yMax, g2, fontSizeIn1_72inches);
		
		// Position:
		yMin += drawShowPosition(page, numPagesWidth, numPagesHeight, fm, xMin, xMax, yMin, yMax, g2, fontSizeIn1_72inches, coreImageInCoreUnits, pageSizeInCoreUnits);
		
		// magnifier:
		Set<LEGOColor.CountingLEGOColor> used = new TreeSet<LEGOColor.CountingLEGOColor>();
		yMax = drawMagnifier(g2, page, numPagesWidth, numPagesHeight, xMin, xMax, yMin, yMax, pageSizeInCoreUnitsW, pageSizeInCoreUnitsH, pf, fm, used);
		
		// Legend:
		g2.setFont(font);
		drawLegend(g2, xMin, xMax, yMin, yMax, fontSizeIn1_72inches, used);
				
	    return PAGE_EXISTS;
	}
	
	public static enum CoverPagePictureType {
		Original, Mosaic, Both, None, Overview;
	}
	public static enum ShowPosition {
		MiddleBox("Box with placement written inside"),
		SmartBox("Box with placement written outside"),
		Written("Text only"),
		TextAndBox("Text and box with location"),
		None("None");
		public String title;
		private ShowPosition(String title) {
			this.title = title;
		}		
	}

	@Override
	public void save(Model<BrickGraphicsState> model) {
		model.set(BrickGraphicsState.PrintCoverPageShow, coverPageShow);
		model.set(BrickGraphicsState.PrintCoverPageShowFileName, coverPageShowFileName);
		model.set(BrickGraphicsState.PrintCoverPageShowLegend, coverPageShowLegend);
		model.set(BrickGraphicsState.PrintCoverPageCoverPictureTypeIndex, coverPagePictureType.ordinal());
		model.set(BrickGraphicsState.PrintShowPositionIndex, showPosition.ordinal());
		model.set(BrickGraphicsState.PrintShowLegend, showLegend);
		model.set(BrickGraphicsState.PrintShowPageNumber, showPageNumber);
		model.set(BrickGraphicsState.PrintMagnifiersPerPage, magnifiersPerPage);
		model.set(BrickGraphicsState.PrintFontSize, fontSizeMM);
		model.set(BrickGraphicsState.PrintMagnifierSizePercentage, magnifierSizePercentage);
		model.set(BrickGraphicsState.PrintDisplayTextDown, downCountDisplayText);
		model.set(BrickGraphicsState.PrintDisplayTextRight, rightCountDisplayText);		
	}

	@Override
	public void imageChanged(BufferedImage image) {
		lastPreparedImage = image;
	}

	@Override
	public void mosaicChanged(Dimension mosaicImageSize) {
		lastMosaicSize = mosaicImageSize;
	}
	
	/**
	 * Show detailed instructions for PDF export
	 */
	private void exportToPDF() {
		Log.log("PDF export requested - showing user instructions.");
		
		String instructions = "Para crear un PDF con las instrucciones detalladas del mosaico:\n\n" +
				"MÉTODO DIRECTO (Recomendado):\n" +
				"1. Usar Print Screen en Windows o Cmd+Shift+3 en macOS\n" +
				"2. Abrir el diálogo de impresión una sola vez más\n" +
				"3. En el diálogo de impresión, buscar la opción 'PDF'\n" +
				"4. Seleccionar 'Save as PDF' o 'Guardar como PDF'\n\n" +
				"MÉTODO ALTERNATIVO:\n" +
				"1. Cerrar completamente la aplicación\n" +
				"2. Volver a abrirla (esto resetea el sistema de impresión)\n" +
				"3. Cargar tu proyecto de nuevo\n" +
				"4. Usar Print → Save as PDF\n\n" +
				"MÉTODO DE EXPORT MANUAL:\n" +
				"1. Usar File → Export para guardar cada página por separado\n" +
				"2. Combinar las imágenes en un documento PDF usando:\n" +
				"   • Preview (macOS): File → Create PDF from images\n" +
				"   • Adobe Reader\n" +
				"   • Herramientas online como SmallPDF\n\n" +
				"¿Prefieres que añada un botón para reiniciar solo el sistema de impresión?";
		
		JTextArea textArea = new JTextArea(instructions);
		textArea.setEditable(false);
		textArea.setWrapStyleWord(true);
		textArea.setLineWrap(true);
		textArea.setCaretPosition(0);
		textArea.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 12));
		
		JScrollPane scrollPane = new JScrollPane(textArea);
		scrollPane.setPreferredSize(new Dimension(550, 450));
		
		String[] options = {"Reiniciar Solo Impresión", "Cerrar"};
		int choice = JOptionPane.showOptionDialog(mw, scrollPane, 
			"Instrucciones para PDF", 
			JOptionPane.YES_NO_OPTION,
			JOptionPane.INFORMATION_MESSAGE,
			null,
			options,
			options[0]);
		
		if(choice == 0) {
			// Reiniciar solo el sistema de impresión
			restartPrintSystem();
		}
			
		Log.log("PDF export instructions shown to user.");
	}
	
	/**
	 * Restart only the print system without losing application state
	 */
	private void restartPrintSystem() {
		try {
			Log.log("Restarting print system only...");
			
			// Clear saved print configuration to force fresh dialog
			hasSuccessfulPrintConfig = false;
			lastUsedPrintService = null;
			savedPageFormat = null;
			
			// Force garbage collection to clear any print dialog state
			System.gc();
			Thread.sleep(200);
			
			JOptionPane.showMessageDialog(mw,
				"Sistema de impresión reiniciado.\n\n" +
				"La próxima impresión mostrará el diálogo de configuración.\n" +
				"Tus configuraciones de colores y ajustes se han mantenido.",
				"Sistema Reiniciado",
				JOptionPane.INFORMATION_MESSAGE);
			
			Log.log("Print system restarted successfully.");
			
		} catch(Exception e) {
			Log.log("Error restarting print system: " + e.getMessage());
			JOptionPane.showMessageDialog(mw,
				"No se pudo reiniciar el sistema de impresión.\n\n" +
				"Intenta cerrar y volver a abrir la aplicación.",
				"Error",
				JOptionPane.WARNING_MESSAGE);
		}
	}
	
	/**
	 * Shows print dialog in a way that's compatible with both source code and JAR execution.
	 */
	private boolean showPrintDialogSafely() {
		try {			
			Log.log("Attempting to show print dialog...");
			boolean result = printerJob.printDialog();
			Log.log("Print dialog result: " + result);
			return result;
		} catch (Exception e) {
			Log.log("Error showing print dialog: " + e.getMessage());
			e.printStackTrace();
			
			// Fallback: Show a message to user
			JOptionPane.showMessageDialog(mw,
				"No se pudo abrir el diálogo de impresión del sistema.\n\n" +
				"Esto puede ocurrir en versiones empaquetadas de la aplicación.\n" +
				"Intenta usar 'Exportar como PDF' desde el menú File.",
				"Problema con diálogo de impresión",
				JOptionPane.WARNING_MESSAGE);
			return false;
		}
	}
}
